# Controle de estoque em PHP

### Requisitos mínimos

Servidor Apache 2.4, PHP ^7.1 e MySQL ^5.7

Este código foi desenvolvido por Márcio Dutra.

Usuarios: admin e vendedor
Senhas:  admin para os dois